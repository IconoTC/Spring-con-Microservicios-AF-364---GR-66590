package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.clients.PedidosClienteREST;
import es.indra.models.Carrito;
import es.indra.persistence.CarritosDAO;

@Service
public class CarritoBSImpl implements ICarritoBS{
	
	@Autowired
	private CarritosDAO dao;
	
	@Autowired
	private PedidosClienteREST clienteFeign;

	@Override
	public Carrito crear(String usuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Carrito agregarPedido(Long id, Integer cantidad, String usuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Carrito consultar(String usuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Carrito eliminarPedido(Long id, String usuario) {
		// TODO Auto-generated method stub
		return null;
	}

}

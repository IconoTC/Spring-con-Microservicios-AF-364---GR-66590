package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IPedidosBS;
import es.indra.models.Pedido;
import es.indra.models.Producto;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
public class PedidosREST {
	
	@Autowired
	private IPedidosBS bs;
	
	// http://localhost:8002/crear/4/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	//@HystrixCommand(fallbackMethod = "manejarError")
	@CircuitBreaker(fallbackMethod = "manejarError", name = "pedidos")
	public Pedido crearPedido(@PathVariable Long id, @PathVariable int cantidad) {
		return bs.crearPedido(id, cantidad);
	}
	
	// El metodo alternativo ha de tener los mismos argumentos + Thowable
	public Pedido manejarError(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + "***************************");
		System.out.println(ex.getClass() + "=======================");
		
		Producto producto = new Producto(id, "Producto vacio", 0);
		
		return new Pedido(producto, cantidad);		
	}

}

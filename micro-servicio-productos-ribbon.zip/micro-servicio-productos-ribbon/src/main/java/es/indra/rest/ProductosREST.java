package es.indra.rest;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IProductosBS;
import es.indra.models.Producto;

@RestController
public class ProductosREST {
	
	@Value("${server.port}")
	private Integer port;
	
	@Autowired
	private IProductosBS bs;
	
	// http:localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		// 1ª opcion
//		List<Producto> lista = bs.consultarTodos();
//		for (Producto producto : lista) {
//			producto.setPort(port);
//		}
//		return lista;
		
		// 2ª opcion -> A partir de Java 8 utilizamos los streams
		return bs.consultarTodos()
				.stream()
				.map(prod -> {
					prod.setPort(port);
					return prod;
				})
				.collect(Collectors.toList());
	}
	
	// http:localhost:8001/buscar/2
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable(name = "id") Long id) {
		Producto producto = bs.buscarProducto(id);
		producto.setPort(port);
		return producto;
	}

}

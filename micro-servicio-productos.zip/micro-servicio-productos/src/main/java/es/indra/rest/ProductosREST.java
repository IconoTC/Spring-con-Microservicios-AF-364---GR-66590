package es.indra.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IProductosBS;
import es.indra.models.Producto;

@RestController
public class ProductosREST {
	
	@Autowired
	private IProductosBS bs;
	
	// http:localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return bs.consultarTodos();
	}
	
	// http:localhost:8001/buscar/2
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable(name = "id") Long id) {
		return bs.buscarProducto(id);
	}

}
